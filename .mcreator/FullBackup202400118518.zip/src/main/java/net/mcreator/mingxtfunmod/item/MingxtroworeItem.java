
package net.mcreator.mingxtfunmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class MingxtroworeItem extends Item {
	public MingxtroworeItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.UNCOMMON));
	}
}
