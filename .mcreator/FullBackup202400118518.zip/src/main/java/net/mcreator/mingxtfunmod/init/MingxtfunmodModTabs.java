
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mingxtfunmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.mingxtfunmod.MingxtfunmodMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MingxtfunmodModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MingxtfunmodMod.MODID);
	public static final RegistryObject<CreativeModeTab> MINGXT_FUN_MOD = REGISTRY.register("mingxt_fun_mod",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.mingxtfunmod.mingxt_fun_mod")).icon(() -> new ItemStack(MingxtfunmodModBlocks.MINGXTBLOCK.get())).displayItems((parameters, tabData) -> {
				tabData.accept(MingxtfunmodModItems.MINNGXTC4B.get());
				tabData.accept(MingxtfunmodModBlocks.MINGXTBLOCK.get().asItem());
				tabData.accept(MingxtfunmodModItems.MINGXTAXE.get());
				tabData.accept(MingxtfunmodModItems.MINGXTPICKZXE.get());
				tabData.accept(MingxtfunmodModItems.MINGXTSWORD.get());
				tabData.accept(MingxtfunmodModItems.MINGXTINGOT.get());
				tabData.accept(MingxtfunmodModBlocks.C_4.get().asItem());
				tabData.accept(MingxtfunmodModItems.MINGXTROWORE.get());
				tabData.accept(MingxtfunmodModItems.MINGXTWUXIANTURCH.get());
				tabData.accept(MingxtfunmodModBlocks.MMINGMEITANX_2.get().asItem());
				tabData.accept(MingxtfunmodModBlocks.MINGMEITANX_22.get().asItem());
				tabData.accept(MingxtfunmodModItems.MINGXTTORCHX_2.get());
				tabData.accept(MingxtfunmodModItems.MINGXTSKUIJIA_HELMET.get());
				tabData.accept(MingxtfunmodModItems.MINGXTSKUIJIA_CHESTPLATE.get());
				tabData.accept(MingxtfunmodModItems.MINGXTSKUIJIA_LEGGINGS.get());
				tabData.accept(MingxtfunmodModItems.MINGXTSKUIJIA_BOOTS.get());
				tabData.accept(MingxtfunmodModItems.MINGXTHOME.get());
			})

					.build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(MingxtfunmodModBlocks.MINGXTORE.get().asItem());
			tabData.accept(MingxtfunmodModBlocks.MINGDEEPORE.get().asItem());
		}
	}
}
