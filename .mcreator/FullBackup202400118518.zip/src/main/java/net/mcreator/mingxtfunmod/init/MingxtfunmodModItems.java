
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mingxtfunmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.mingxtfunmod.item.MinngxtcpubItem;
import net.mcreator.mingxtfunmod.item.MingxtwuxianturchItem;
import net.mcreator.mingxtfunmod.item.Mingxttorchx2Item;
import net.mcreator.mingxtfunmod.item.MingxtswordItem;
import net.mcreator.mingxtfunmod.item.MingxtskuijiaItem;
import net.mcreator.mingxtfunmod.item.MingxtroworeItem;
import net.mcreator.mingxtfunmod.item.MingxtpickzxeItem;
import net.mcreator.mingxtfunmod.item.MingxtingotItem;
import net.mcreator.mingxtfunmod.item.MingxthomeItem;
import net.mcreator.mingxtfunmod.item.MingxtaxeItem;
import net.mcreator.mingxtfunmod.MingxtfunmodMod;

public class MingxtfunmodModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MingxtfunmodMod.MODID);
	public static final RegistryObject<Item> MINNGXTC4B = REGISTRY.register("minngxtc4b", () -> new MinngxtcpubItem());
	public static final RegistryObject<Item> MINGXTBLOCK = block(MingxtfunmodModBlocks.MINGXTBLOCK);
	public static final RegistryObject<Item> MINGXTAXE = REGISTRY.register("mingxtaxe", () -> new MingxtaxeItem());
	public static final RegistryObject<Item> MINGXTPICKZXE = REGISTRY.register("mingxtpickzxe", () -> new MingxtpickzxeItem());
	public static final RegistryObject<Item> MINGXTSWORD = REGISTRY.register("mingxtsword", () -> new MingxtswordItem());
	public static final RegistryObject<Item> MINGXTINGOT = REGISTRY.register("mingxtingot", () -> new MingxtingotItem());
	public static final RegistryObject<Item> C_4 = block(MingxtfunmodModBlocks.C_4);
	public static final RegistryObject<Item> MINGXTORE = block(MingxtfunmodModBlocks.MINGXTORE);
	public static final RegistryObject<Item> MINGXTROWORE = REGISTRY.register("mingxtrowore", () -> new MingxtroworeItem());
	public static final RegistryObject<Item> MINGDEEPORE = block(MingxtfunmodModBlocks.MINGDEEPORE);
	public static final RegistryObject<Item> MINGXTWUXIANTURCH = REGISTRY.register("mingxtwuxianturch", () -> new MingxtwuxianturchItem());
	public static final RegistryObject<Item> MMINGMEITANX_2 = block(MingxtfunmodModBlocks.MMINGMEITANX_2);
	public static final RegistryObject<Item> MINGMEITANX_22 = block(MingxtfunmodModBlocks.MINGMEITANX_22);
	public static final RegistryObject<Item> MINGXTTORCHX_2 = REGISTRY.register("mingxttorchx_2", () -> new Mingxttorchx2Item());
	public static final RegistryObject<Item> MINGXTSKUIJIA_HELMET = REGISTRY.register("mingxtskuijia_helmet", () -> new MingxtskuijiaItem.Helmet());
	public static final RegistryObject<Item> MINGXTSKUIJIA_CHESTPLATE = REGISTRY.register("mingxtskuijia_chestplate", () -> new MingxtskuijiaItem.Chestplate());
	public static final RegistryObject<Item> MINGXTSKUIJIA_LEGGINGS = REGISTRY.register("mingxtskuijia_leggings", () -> new MingxtskuijiaItem.Leggings());
	public static final RegistryObject<Item> MINGXTSKUIJIA_BOOTS = REGISTRY.register("mingxtskuijia_boots", () -> new MingxtskuijiaItem.Boots());
	public static final RegistryObject<Item> MINGXTHOME = REGISTRY.register("mingxthome", () -> new MingxthomeItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
