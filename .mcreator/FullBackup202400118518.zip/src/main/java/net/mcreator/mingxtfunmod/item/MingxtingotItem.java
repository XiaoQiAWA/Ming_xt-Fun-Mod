
package net.mcreator.mingxtfunmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class MingxtingotItem extends Item {
	public MingxtingotItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
