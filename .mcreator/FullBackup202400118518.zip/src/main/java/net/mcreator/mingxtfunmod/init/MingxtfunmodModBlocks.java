
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mingxtfunmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.mingxtfunmod.block.Mmingmeitanx2Block;
import net.mcreator.mingxtfunmod.block.MingxtoreBlock;
import net.mcreator.mingxtfunmod.block.MingxthomePortalBlock;
import net.mcreator.mingxtfunmod.block.MingxtblockBlock;
import net.mcreator.mingxtfunmod.block.Mingmeitanx22Block;
import net.mcreator.mingxtfunmod.block.MingdeeporeBlock;
import net.mcreator.mingxtfunmod.block.C4Block;
import net.mcreator.mingxtfunmod.MingxtfunmodMod;

public class MingxtfunmodModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MingxtfunmodMod.MODID);
	public static final RegistryObject<Block> MINGXTBLOCK = REGISTRY.register("mingxtblock", () -> new MingxtblockBlock());
	public static final RegistryObject<Block> C_4 = REGISTRY.register("c_4", () -> new C4Block());
	public static final RegistryObject<Block> MINGXTORE = REGISTRY.register("mingxtore", () -> new MingxtoreBlock());
	public static final RegistryObject<Block> MINGDEEPORE = REGISTRY.register("mingdeepore", () -> new MingdeeporeBlock());
	public static final RegistryObject<Block> MMINGMEITANX_2 = REGISTRY.register("mmingmeitanx_2", () -> new Mmingmeitanx2Block());
	public static final RegistryObject<Block> MINGMEITANX_22 = REGISTRY.register("mingmeitanx_22", () -> new Mingmeitanx22Block());
	public static final RegistryObject<Block> MINGXTHOME_PORTAL = REGISTRY.register("mingxthome_portal", () -> new MingxthomePortalBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
